 $('.searchType').click(function(){
               
alert("sfsdfd");
                //var check= $(this).val();

               /* $.ajax({
                    url: './opt/index_opt.php',
                    type: 'POST',
                    data: {check:check},
                    success: function(data){
                        alert(data);
                    }
                });*/
            });
