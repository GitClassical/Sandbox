<?php load_template( get_template_directory() . '/header.php' ); ?>



<!-- Activate page wrappers -->
<div id="wrapper">
<div id="main_wrapper" class="clearfix">
<div id="page_wrapper">
<div id="content">



